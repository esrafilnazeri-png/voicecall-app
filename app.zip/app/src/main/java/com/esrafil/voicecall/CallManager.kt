package com.esrafil.voicecall

import android.content.Context
import io.livekit.android.LiveKit
import io.livekit.android.events.RoomEvent
import io.livekit.android.room.Room
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Person(val name: String, val bio: String, val speaking: Boolean, val me: Boolean)

object CallManager {
    var status = "idle" // idle | connecting | connected | reconnecting
    var muted = false
    var error: String? = null
    var people: List<Person> = emptyList()
    var onChange: (() -> Unit)? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var room: Room? = null
    private var job: Job? = null
    private var events: Job? = null
    private var appCtx: Context? = null

    fun connect(ctx: Context, server: String, username: String, name: String, bio: String, deviceId: String) {
        if (status != "idle") return
        val app = ctx.applicationContext
        appCtx = app
        status = "connecting"
        error = null
        muted = false
        people = emptyList()
        onChange?.invoke()
        job = scope.launch {
            try {
                val (url, token) = withContext(Dispatchers.IO) {
                    fetchToken(server, username, name, bio, deviceId)
                }
                val r = LiveKit.create(app)
                room = r
                events = launch { r.events.collect { onEvent(it) } }
                r.connect(url, token)
                r.localParticipant.setMicrophoneEnabled(true)
                status = "connected"
                CallService.start(app)
                refresh()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "اتصال برقرار نشد: " + (e.message ?: "خطای نامشخص")
                cleanup()
            }
        }
    }

    fun disconnect() {
        job?.cancel()
        cleanup()
    }

    fun toggleMute() {
        val r = room ?: return
        scope.launch {
            val newMuted = !muted
            try {
                r.localParticipant.setMicrophoneEnabled(!newMuted)
                muted = newMuted
            } catch (_: Exception) {
            }
            onChange?.invoke()
        }
    }

    private fun onEvent(e: RoomEvent) {
        when (e) {
            is RoomEvent.Reconnecting -> status = "reconnecting"
            is RoomEvent.Reconnected -> status = "connected"
            is RoomEvent.Disconnected -> {
                error = "تماس قطع شد"
                scope.launch { cleanup() }
                return
            }
            else -> {}
        }
        refresh()
    }

    private fun refresh() {
        val r = room
        if (r != null && status != "connecting" && status != "idle") {
            val list = mutableListOf<Person>()
            val lp = r.localParticipant
            list.add(Person(lp.name ?: "من", bioOf(lp.metadata), lp.isSpeaking, true))
            for (p in r.remoteParticipants.values) {
                list.add(Person(p.name ?: "کاربر", bioOf(p.metadata), p.isSpeaking, false))
            }
            people = list
        }
        onChange?.invoke()
    }

    private fun cleanup() {
        events?.cancel()
        events = null
        room?.let {
            try {
                it.disconnect()
                it.release()
            } catch (_: Exception) {
            }
        }
        room = null
        status = "idle"
        muted = false
        people = emptyList()
        appCtx?.let { CallService.stop(it) }
        onChange?.invoke()
    }

    private fun bioOf(m: String?): String =
        try { JSONObject(m ?: "{}").optString("b", "") } catch (_: Exception) { "" }

    private fun fetchToken(server: String, username: String, name: String, bio: String, deviceId: String): Pair<String, String> {
        val c = URL(server.trimEnd('/') + "/token").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        val body = JSONObject()
            .put("username", username).put("name", name)
            .put("bio", bio).put("deviceId", deviceId).toString()
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("سرور پاسخ $code داد")
        val j = JSONObject(text)
        return Pair(j.getString("url"), j.getString("token"))
    }
}
