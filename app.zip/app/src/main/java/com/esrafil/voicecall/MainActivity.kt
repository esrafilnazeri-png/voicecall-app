package com.esrafil.voicecall

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

class MainActivity : Activity() {
    private val BG = Color.parseColor("#0F1115")
    private val CARD = Color.parseColor("#1A1D24")
    private val GRAY = Color.parseColor("#8A93A3")
    private val GREEN = Color.parseColor("#2ECC71")
    private val RED = Color.parseColor("#E74C3C")
    private val BLUE = Color.parseColor("#2F80ED")

    private lateinit var root: FrameLayout
    private var editing = false
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        setContentView(root)
        if (prefs.getString("deviceId", null) == null) {
            prefs.edit().putString("deviceId", UUID.randomUUID().toString()).apply()
        }
    }

    override fun onStart() {
        super.onStart()
        CallManager.onChange = { render() }
        render()
    }

    override fun onStop() {
        super.onStop()
        CallManager.onChange = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun tv(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun field(hint: String, value: String) = EditText(this).apply {
        setHint(hint)
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(GRAY)
        background = rounded(CARD, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun lp(top: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(top) }

    private fun render() {
        root.removeAllViews()
        if (editing || prefs.getString("username", "").isNullOrEmpty()) showProfile() else showMain()
    }

    private fun showProfile() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(24))
        }
        col.addView(tv("پروفایل", 24f, bold = true))
        val u = field("نام کاربری (حروف انگلیسی، عدد و _)", prefs.getString("username", "") ?: "")
        val n = field("نام", prefs.getString("name", "") ?: "")
        val bio = field("بیو", prefs.getString("bio", "") ?: "")
        val s = field("آدرس سرور (https://...workers.dev)", prefs.getString("server", "") ?: "")
        col.addView(u, lp(20)); col.addView(n, lp(12)); col.addView(bio, lp(12))
        col.addView(tv("تنظیمات سرور", 14f, GRAY), lp(24))
        col.addView(s, lp(8))
        val save = tv("ذخیره", 16f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(BLUE, 14)
            setPadding(0, dp(14), 0, dp(14))
        }
        col.addView(save, lp(24))
        save.setOnClickListener {
            val un = u.text.toString().trim()
            val nm = n.text.toString().trim()
            val bi = bio.text.toString().trim()
            var sv = s.text.toString().trim().trimEnd('/')
            if (!Regex("^[A-Za-z0-9_]{3,20}$").matches(un)) {
                toast("نام کاربری باید ۳ تا ۲۰ حرف انگلیسی، عدد یا _ باشد"); return@setOnClickListener
            }
            if (nm.isEmpty() || nm.length > 30) {
                toast("نام را وارد کنید (حداکثر ۳۰ حرف)"); return@setOnClickListener
            }
            if (bi.length > 100) {
                toast("بیو حداکثر ۱۰۰ حرف"); return@setOnClickListener
            }
            if (sv.isEmpty()) {
                toast("آدرس سرور را وارد کنید"); return@setOnClickListener
            }
            if (!sv.startsWith("http://") && !sv.startsWith("https://")) sv = "https://$sv"
            prefs.edit().putString("username", un).putString("name", nm)
                .putString("bio", bi).putString("server", sv).apply()
            editing = false
            render()
        }
        root.addView(ScrollView(this).apply { addView(col) })
    }

    private fun showMain() {
        val st = CallManager.status
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("تماس صوتی", 22f, bold = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val edit = tv("پروفایل", 14f, BLUE)
        edit.setOnClickListener {
            if (st == "idle") { editing = true; render() } else toast("اول تماس را قطع کنید")
        }
        head.addView(edit)
        col.addView(head, lp())
        col.addView(
            tv(prefs.getString("name", "") + "  @" + prefs.getString("username", ""), 14f, GRAY), lp(4)
        )

        val statusText = when (st) {
            "connecting" -> "در حال اتصال…"
            "connected" -> "متصل هستید"
            "reconnecting" -> "ارتباط قطع شد، در حال اتصال مجدد…"
            else -> "آماده"
        }
        col.addView(tv(statusText, 15f, if (st == "connected") GREEN else GRAY).apply { gravity = Gravity.CENTER }, lp(32))

        val big = tv(
            when (st) { "idle" -> "اتصال به کال"; "connecting" -> "…"; else -> "قطع تماس" },
            20f, Color.WHITE, true
        ).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(when (st) { "idle" -> GREEN; "connecting" -> GRAY; else -> RED })
            }
        }
        big.setOnClickListener {
            when (CallManager.status) {
                "idle" -> startCall()
                "connecting" -> {}
                else -> CallManager.disconnect()
            }
        }
        col.addView(big, LinearLayout.LayoutParams(dp(180), dp(180)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(20)
        })

        if (st == "connected" || st == "reconnecting") {
            val mute = tv(if (CallManager.muted) "میکروفون خاموش (لمس برای روشن)" else "بی‌صدا کردن میکروفون", 15f, Color.WHITE).apply {
                gravity = Gravity.CENTER
                background = rounded(CARD, 14)
                setPadding(0, dp(12), 0, dp(12))
            }
            mute.setOnClickListener { CallManager.toggleMute() }
            col.addView(mute, lp(20))
        }

        CallManager.error?.let { col.addView(tv(it, 14f, RED).apply { gravity = Gravity.CENTER }, lp(16)) }

        if (CallManager.people.isNotEmpty()) {
            col.addView(tv("حاضران (${CallManager.people.size})", 15f, GRAY), lp(28))
            for (p in CallManager.people) {
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(CARD, 12)
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                }
                card.addView(tv(p.name + if (p.me) " (شما)" else "", 16f, if (p.speaking) GREEN else Color.WHITE, true))
                if (p.bio.isNotEmpty()) card.addView(tv(p.bio, 13f, GRAY))
                col.addView(card, lp(8))
            }
        }
        root.addView(ScrollView(this).apply { addView(col) })
    }

    private fun startCall() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) doConnect() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) doConnect()
        else toast("برای تماس، دسترسی میکروفون لازم است")
    }

    private fun doConnect() {
        CallManager.connect(
            this,
            prefs.getString("server", "") ?: "",
            prefs.getString("username", "") ?: "",
            prefs.getString("name", "") ?: "",
            prefs.getString("bio", "") ?: "",
            prefs.getString("deviceId", "") ?: ""
        )
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
